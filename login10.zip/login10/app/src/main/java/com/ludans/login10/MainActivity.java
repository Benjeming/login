package com.ludans.login10;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;




public class MainActivity extends AppCompatActivity implements View.OnClickListener {


    private EditText Ed_username;
    private EditText Ed_password;
    private Button Bt_reset;
    private Button Bt_login;
    private String username;
    private String password;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_activity);
        initView();
    }

    private void initView() {
        Ed_username = findViewById(R.id.Ed_usernaem);
        Ed_password = findViewById(R.id.Ed_password);
        Bt_login = findViewById(R.id.Bt_login);
        Bt_reset = findViewById(R.id.Bt_reset);

        Bt_login.setOnClickListener(this);
        Bt_reset.setOnClickListener(this);
    }

    private Runnable runnable = new Runnable() {
        @Override
        public void run() {
            try {
                String  ip = "192.168.43.224";
                String dbname = "testlogin1";
                String useraccont = "ludans";
                String userpassword="123456";


                Class.forName("com.mysql.jdbc.Driver");
                Connection conn = DriverManager.getConnection("jdbc:mysql://"+ip+"/+dbname+",useraccont,userpassword);
                String sql = "select * from userlogin where account = ? and passwd = ?";
                Log.d("run" ,"run1");
                PreparedStatement pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, username);
                pstmt.setString(2, password);
                ResultSet rs = pstmt.executeQuery();

                if (rs.next()){
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Log.d("run", "run2");
                            Toast.makeText(MainActivity.this, "登录成功", Toast.LENGTH_SHORT).show();
                        }
                    });
                }else {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Log.d("run", "run3");
                            Toast.makeText(MainActivity.this, "用户名或密码错误", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
                JDBCUtils.close(rs,pstmt,conn);

            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    };










    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.Bt_login:
                submit();
                break;
            case R.id.Bt_reset:
//                startActivity(new Intent(LoginActivity.this, RegisterActivity.class));
                Ed_password.setText("");
                Ed_username.setText("");
                break;
        }
    }


    private void submit() {
        username = Ed_username.getText().toString().trim();
        if (TextUtils.isEmpty(username)) {
            Toast.makeText(this, "账号不能为空", Toast.LENGTH_SHORT).show();
            return;
        }

        password = Ed_password.getText().toString().trim();
        if (TextUtils.isEmpty(password)) {
            Toast.makeText(this, "密码不能为空", Toast.LENGTH_SHORT).show();
            return;
        }

        //新建一个线程 因为 Android 主程序中不允许直接使用网络
        new Thread(runnable).start();
    }

}